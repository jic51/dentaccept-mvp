# DentAccept — Next.js 14 Frontend

An in-office dental case acceptance tool where dentists show bilingual (EN/ES) procedure videos chairside on an iPad.

## Tech Stack

- **Next.js 14** (App Router)
- **Tailwind CSS** with custom dental color palette
- **Supabase** (Auth + PostgreSQL + Row Level Security)
- **TypeScript**
- **Framer Motion** for animations
- **React Player** for video playback
- **Lucide React** for icons

## Getting Started

```bash
# 1. Install dependencies
npm install

# 2. Set up environment variables
cp .env.local.example .env.local
# Fill in your Supabase URL and keys

# 3. Run the Supabase migration
# In your Supabase dashboard → SQL Editor, run:
# supabase/migrations/001_initial.sql

# 4. Start the dev server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to view the landing page.

## Project Structure

```
src/
├── app/
│   ├── page.tsx                    # Marketing landing page
│   ├── layout.tsx                  # Root layout with LanguageProvider
│   ├── globals.css                 # Tailwind + global styles
│   ├── auth/
│   │   ├── login/page.tsx
│   │   ├── signup/page.tsx
│   │   └── forgot-password/page.tsx
│   ├── dashboard/
│   │   ├── layout.tsx              # Responsive sidebar layout
│   │   ├── page.tsx                # Dashboard home
│   │   ├── library/page.tsx        # Procedure library w/ search & filters
│   │   ├── analytics/page.tsx      # Presentation analytics
│   │   └── settings/page.tsx       # Practice settings
│   └── chairside/
│       └── page.tsx                # 4-step chairside presentation flow
├── components/
│   ├── LanguageToggle.tsx          # EN/ES language switcher
│   ├── SearchBar.tsx
│   ├── CategoryFilter.tsx
│   ├── ProcedureCard.tsx
│   ├── VideoPlayer.tsx             # react-player wrapper
│   └── OutcomeSelector.tsx         # Patient decision buttons
├── context/
│   └── LanguageContext.tsx         # Bilingual t(en, es) provider
├── lib/
│   └── supabase/
│       ├── browser.ts              # Client-side Supabase
│       └── server.ts               # Server-side Supabase (RSC/Actions)
├── middleware.ts                   # Auth route protection
└── types/
    ├── database.ts                 # Supabase table types
    └── index.ts                    # Exported app types
```

## Chairside Flow

The core product is the **4-step chairside presentation**:

1. **Video** — Watch the procedure explanation video
2. **What to Expect** — Step-by-step numbered slides
3. **If Left Untreated** — Consequences of not treating
4. **Your Decision** — Patient taps Accepted / Declined / Pending / Callback

All 4 steps are fully bilingual — toggle EN/ES at any point.

## Database Schema

6 tables:
- `offices` — Practice accounts
- `office_members` — Staff → office mapping with roles
- `categories` — Procedure categories (bilingual)
- `procedures` — The video library (bilingual name, desc, slides)
- `favorites` — Per-office favorites
- `presentations` — Session tracking with outcome

All tables use Row Level Security (RLS) for multi-tenant isolation.

## Seed Procedures

1. Dental Crown
2. Root Canal
3. Dental Implant
4. Tooth Extraction
5. Teeth Whitening
6. Deep Cleaning (SRP)

## Color Palette

- **dental-600** (#0177c5) — Primary brand blue
- **teal-500** (#05c7b1) — Accent teal
- **success-600** (#16a34a) — Acceptance green
- **dental-950** (#072c48) — Chairside dark background
