-- DentAccept database schema
-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ──────────────────────────────────────────────────────────────────────────────
-- OFFICES
-- ──────────────────────────────────────────────────────────────────────────────
create table public.offices (
  id          uuid primary key default uuid_generate_v4(),
  name        text not null,
  slug        text unique not null,
  logo_url    text,
  plan        text not null default 'starter' check (plan in ('starter','pro','enterprise')),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
alter table public.offices enable row level security;
create policy "office members can read own office"
  on public.offices for select
  using (id in (
    select office_id from public.office_members where user_id = auth.uid()
  ));

-- ──────────────────────────────────────────────────────────────────────────────
-- OFFICE MEMBERS
-- ──────────────────────────────────────────────────────────────────────────────
create table public.office_members (
  id         uuid primary key default uuid_generate_v4(),
  office_id  uuid not null references public.offices(id) on delete cascade,
  user_id    uuid not null references auth.users(id) on delete cascade,
  role       text not null default 'staff' check (role in ('owner','admin','staff')),
  created_at timestamptz not null default now(),
  unique(office_id, user_id)
);
alter table public.office_members enable row level security;
create policy "members can view own memberships"
  on public.office_members for select
  using (user_id = auth.uid());
create index idx_office_members_user on public.office_members(user_id);
create index idx_office_members_office on public.office_members(office_id);

-- ──────────────────────────────────────────────────────────────────────────────
-- CATEGORIES
-- ──────────────────────────────────────────────────────────────────────────────
create table public.categories (
  id         uuid primary key default uuid_generate_v4(),
  name_en    text not null,
  name_es    text not null,
  icon       text,
  sort_order integer not null default 0
);
alter table public.categories enable row level security;
create policy "categories are public read"
  on public.categories for select using (true);

-- ──────────────────────────────────────────────────────────────────────────────
-- PROCEDURES
-- ──────────────────────────────────────────────────────────────────────────────
create table public.procedures (
  id                uuid primary key default uuid_generate_v4(),
  category_id       uuid references public.categories(id),
  name_en           text not null,
  name_es           text not null,
  description_en    text,
  description_es    text,
  video_url         text,
  thumbnail_url     text,
  duration_seconds  integer,
  -- what to expect slides
  expect_en         jsonb default '[]',
  expect_es         jsonb default '[]',
  -- consequences of NOT treating
  consequences_en   jsonb default '[]',
  consequences_es   jsonb default '[]',
  tags              text[] default '{}',
  is_active         boolean not null default true,
  created_at        timestamptz not null default now()
);
alter table public.procedures enable row level security;
create policy "procedures are public read"
  on public.procedures for select using (true);
create index idx_procedures_category on public.procedures(category_id);

-- ──────────────────────────────────────────────────────────────────────────────
-- FAVORITES (per office)
-- ──────────────────────────────────────────────────────────────────────────────
create table public.favorites (
  id           uuid primary key default uuid_generate_v4(),
  office_id    uuid not null references public.offices(id) on delete cascade,
  procedure_id uuid not null references public.procedures(id) on delete cascade,
  created_by   uuid references auth.users(id),
  created_at   timestamptz not null default now(),
  unique(office_id, procedure_id)
);
alter table public.favorites enable row level security;
create policy "office members can manage favorites"
  on public.favorites for all
  using (office_id in (
    select office_id from public.office_members where user_id = auth.uid()
  ));
create index idx_favorites_office on public.favorites(office_id);

-- ──────────────────────────────────────────────────────────────────────────────
-- PRESENTATIONS (session tracking)
-- ──────────────────────────────────────────────────────────────────────────────
create table public.presentations (
  id           uuid primary key default uuid_generate_v4(),
  office_id    uuid not null references public.offices(id) on delete cascade,
  procedure_id uuid not null references public.procedures(id),
  presented_by uuid references auth.users(id),
  language     text not null default 'en' check (language in ('en','es')),
  outcome      text check (outcome in ('accepted','declined','pending','callback')),
  notes        text,
  started_at   timestamptz not null default now(),
  completed_at timestamptz
);
alter table public.presentations enable row level security;
create policy "office members can manage presentations"
  on public.presentations for all
  using (office_id in (
    select office_id from public.office_members where user_id = auth.uid()
  ));
create index idx_presentations_office on public.presentations(office_id);
create index idx_presentations_date on public.presentations(started_at);

-- ──────────────────────────────────────────────────────────────────────────────
-- TRIGGERS
-- ──────────────────────────────────────────────────────────────────────────────
create or replace function public.handle_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
create trigger offices_updated_at
  before update on public.offices
  for each row execute function public.handle_updated_at();

-- ──────────────────────────────────────────────────────────────────────────────
-- SEED DATA
-- ──────────────────────────────────────────────────────────────────────────────
insert into public.categories (id, name_en, name_es, icon, sort_order) values
  ('c1000000-0000-0000-0000-000000000001', 'Restorative', 'Restaurativo', 'tooth', 1),
  ('c1000000-0000-0000-0000-000000000002', 'Endodontics', 'Endodoncia', 'activity', 2),
  ('c1000000-0000-0000-0000-000000000003', 'Implants', 'Implantes', 'anchor', 3),
  ('c1000000-0000-0000-0000-000000000004', 'Oral Surgery', 'Cirugía Oral', 'scissors', 4),
  ('c1000000-0000-0000-0000-000000000005', 'Cosmetic', 'Cosmético', 'star', 5),
  ('c1000000-0000-0000-0000-000000000006', 'Preventive', 'Preventivo', 'shield', 6);

insert into public.procedures
  (id, category_id, name_en, name_es, description_en, description_es,
   video_url, thumbnail_url, duration_seconds, expect_en, expect_es,
   consequences_en, consequences_es, tags)
values
  ('p1000000-0000-0000-0000-000000000001',
   'c1000000-0000-0000-0000-000000000001',
   'Dental Crown', 'Corona Dental',
   'A crown restores a damaged tooth to its original shape, size, and function.',
   'Una corona restaura un diente dañado a su forma, tamaño y función originales.',
   'https://www.youtube.com/watch?v=placeholder_crown',
   'https://placehold.co/640x360/0d95e7/ffffff?text=Crown',
   180,
   '["Two appointments required","Tooth is shaped and a temporary crown placed","Final crown cemented on second visit","Mild sensitivity is normal"]',
   '["Se requieren dos citas","El diente se prepara y se coloca una corona temporal","La corona final se cementa en la segunda visita","Es normal cierta sensibilidad"]',
   '["Tooth fracture or breakage","Increased decay and infection","Possible tooth loss","More expensive treatment later"]',
   '["Fractura o rotura del diente","Mayor caries e infección","Posible pérdida del diente","Tratamiento más costoso después"]',
   '{crown,restorative,common}'),

  ('p1000000-0000-0000-0000-000000000002',
   'c1000000-0000-0000-0000-000000000002',
   'Root Canal', 'Tratamiento de Conducto',
   'Root canal therapy removes infected pulp to save a tooth and eliminate pain.',
   'El tratamiento de conducto elimina la pulpa infectada para salvar el diente y eliminar el dolor.',
   'https://www.youtube.com/watch?v=placeholder_rootcanal',
   'https://placehold.co/640x360/025f9f/ffffff?text=Root+Canal',
   240,
   '["Local anesthesia keeps you comfortable","Infected tissue removed","Canal cleaned and sealed","Crown often recommended afterward"]',
   '["La anestesia local te mantiene cómodo","Se elimina el tejido infectado","El canal se limpia y sella","A menudo se recomienda una corona después"]',
   '["Spreading infection to jaw or other teeth","Abscess formation","Systemic health complications","Loss of the tooth"]',
   '["La infección se puede extender a la mandíbula u otros dientes","Formación de absceso","Complicaciones de salud sistémica","Pérdida del diente"]',
   '{root-canal,endodontics,pain-relief}'),

  ('p1000000-0000-0000-0000-000000000003',
   'c1000000-0000-0000-0000-000000000003',
   'Dental Implant', 'Implante Dental',
   'Implants are titanium roots that permanently replace missing teeth.',
   'Los implantes son raíces de titanio que reemplazan permanentemente los dientes perdidos.',
   'https://www.youtube.com/watch?v=placeholder_implant',
   'https://placehold.co/640x360/067f75/ffffff?text=Implant',
   300,
   '["Titanium post surgically placed in jawbone","3-6 month healing period (osseointegration)","Abutment and crown attached","Looks and feels like a natural tooth"]',
   '["La pieza de titanio se coloca quirúrgicamente en el hueso","Período de curación de 3-6 meses (osteointegración)","Se coloca el pilar y la corona","Se ve y se siente como un diente natural"]',
   '["Bone loss at the missing tooth site","Shifting of adjacent teeth","Difficulty chewing and speaking","Changes in facial appearance"]',
   '["Pérdida ósea en el sitio del diente faltante","Desplazamiento de dientes adyacentes","Dificultad para masticar y hablar","Cambios en la apariencia facial"]',
   '{implant,missing-tooth,permanent}'),

  ('p1000000-0000-0000-0000-000000000004',
   'c1000000-0000-0000-0000-000000000004',
   'Tooth Extraction', 'Extracción Dental',
   'Extraction removes a tooth that cannot be saved due to damage or infection.',
   'La extracción elimina un diente que no se puede salvar debido a daño o infección.',
   'https://www.youtube.com/watch?v=placeholder_extraction',
   'https://placehold.co/640x360/0b446c/ffffff?text=Extraction',
   90,
   '["Local anesthesia numbs the area","Tooth is gently loosened and removed","Gauze placed to control bleeding","Healing takes 1-2 weeks"]',
   '["La anestesia local adormece el área","El diente se afloja suavemente y se extrae","Se coloca gasa para controlar el sangrado","La curación tarda 1-2 semanas"]',
   '["Spreading infection","Damage to adjacent teeth","Severe pain and swelling","Emergency situation requiring immediate care"]',
   '["Infección que se extiende","Daño a los dientes adyacentes","Dolor intenso e hinchazón","Situación de emergencia que requiere atención inmediata"]',
   '{extraction,oral-surgery}'),

  ('p1000000-0000-0000-0000-000000000005',
   'c1000000-0000-0000-0000-000000000005',
   'Teeth Whitening', 'Blanqueamiento Dental',
   'Professional whitening dramatically brightens your smile in one visit.',
   'El blanqueamiento profesional ilumina drásticamente tu sonrisa en una sola visita.',
   'https://www.youtube.com/watch?v=placeholder_whitening',
   'https://placehold.co/640x360/21e4cb/072c48?text=Whitening',
   120,
   '["Protective gel applied to gums","Whitening agent applied to teeth","Activated by special light","Results visible immediately"]',
   '["Se aplica gel protector en las encías","Se aplica agente blanqueador en los dientes","Se activa con luz especial","Los resultados son visibles de inmediato"]',
   '["Continued staining and yellowing","Less confident smile","First impressions matter","Results harder to achieve over time"]',
   '["Continúa el manchado y amarillamiento","Sonrisa menos segura","Las primeras impresiones importan","Los resultados son más difíciles de lograr con el tiempo"]',
   '{whitening,cosmetic,quick}'),

  ('p1000000-0000-0000-0000-000000000006',
   'c1000000-0000-0000-0000-000000000006',
   'Deep Cleaning (SRP)', 'Limpieza Profunda (RAR)',
   'Scaling and root planing treats gum disease by removing tartar below the gum line.',
   'El raspado y alisado radicular trata la enfermedad de las encías eliminando el sarro debajo de la línea de las encías.',
   'https://www.youtube.com/watch?v=placeholder_srp',
   'https://placehold.co/640x360/16a34a/ffffff?text=Deep+Cleaning',
   150,
   '["Anesthesia keeps you comfortable","Tartar and bacteria removed from below gumline","Root surfaces smoothed","Follow-up visit to check healing"]',
   '["La anestesia te mantiene cómodo","Se elimina el sarro y las bacterias debajo de la línea de las encías","Las superficies radiculares se alisan","Visita de seguimiento para verificar la curación"]',
   '["Progressive bone and tooth loss","Gum recession","Systemic link to heart disease and diabetes","Eventual tooth loss"]',
   '["Pérdida progresiva de hueso y dientes","Recesión de las encías","Vinculación sistémica con enfermedades cardíacas y diabetes","Eventual pérdida de dientes"]',
   '{gum-disease,preventive,periodontal}');
