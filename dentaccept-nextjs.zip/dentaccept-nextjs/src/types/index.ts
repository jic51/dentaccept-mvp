import type { Database } from './database'

export type Office = Database['public']['Tables']['offices']['Row']
export type Category = Database['public']['Tables']['categories']['Row']
export type Procedure = Database['public']['Tables']['procedures']['Row']
export type Favorite = Database['public']['Tables']['favorites']['Row']
export type Presentation = Database['public']['Tables']['presentations']['Row']

export type Language = 'en' | 'es'

export type ProcedureWithCategory = Procedure & {
  categories: Category | null
}

export type PresentationOutcome = 'accepted' | 'declined' | 'pending' | 'callback'

// Chairside flow steps
export type ChairsideStep = 'video' | 'expect' | 'consequences' | 'decision'
