export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      offices: {
        Row: {
          id: string; name: string; slug: string; logo_url: string | null
          plan: 'starter' | 'pro' | 'enterprise'; created_at: string; updated_at: string
        }
        Insert: { id?: string; name: string; slug: string; logo_url?: string | null; plan?: 'starter' | 'pro' | 'enterprise' }
        Update: { id?: string; name?: string; slug?: string; logo_url?: string | null; plan?: 'starter' | 'pro' | 'enterprise' }
      }
      office_members: {
        Row: { id: string; office_id: string; user_id: string; role: 'owner' | 'admin' | 'staff'; created_at: string }
        Insert: { office_id: string; user_id: string; role?: 'owner' | 'admin' | 'staff' }
        Update: { role?: 'owner' | 'admin' | 'staff' }
      }
      categories: {
        Row: { id: string; name_en: string; name_es: string; icon: string | null; sort_order: number }
        Insert: { name_en: string; name_es: string; icon?: string | null; sort_order?: number }
        Update: { name_en?: string; name_es?: string; icon?: string | null; sort_order?: number }
      }
      procedures: {
        Row: {
          id: string; category_id: string | null
          name_en: string; name_es: string
          description_en: string | null; description_es: string | null
          video_url: string | null; thumbnail_url: string | null
          duration_seconds: number | null
          expect_en: Json; expect_es: Json
          consequences_en: Json; consequences_es: Json
          tags: string[]; is_active: boolean; created_at: string
        }
        Insert: { name_en: string; name_es: string; category_id?: string | null }
        Update: { name_en?: string; name_es?: string; is_active?: boolean }
      }
      favorites: {
        Row: { id: string; office_id: string; procedure_id: string; created_by: string | null; created_at: string }
        Insert: { office_id: string; procedure_id: string; created_by?: string | null }
        Update: Record<string, never>
      }
      presentations: {
        Row: {
          id: string; office_id: string; procedure_id: string; presented_by: string | null
          language: 'en' | 'es'; outcome: 'accepted' | 'declined' | 'pending' | 'callback' | null
          notes: string | null; started_at: string; completed_at: string | null
        }
        Insert: { office_id: string; procedure_id: string; language?: 'en' | 'es'; presented_by?: string | null }
        Update: { outcome?: 'accepted' | 'declined' | 'pending' | 'callback'; notes?: string; completed_at?: string }
      }
    }
    Views: Record<string, never>
    Functions: Record<string, never>
    Enums: Record<string, never>
  }
}
