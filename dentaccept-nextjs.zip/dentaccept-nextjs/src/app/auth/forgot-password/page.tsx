'use client'
import { useState } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/browser'
import { useLanguage } from '@/context/LanguageContext'
import { Loader2, ArrowLeft } from 'lucide-react'

export default function ForgotPasswordPage() {
  const { t } = useLanguage()
  const supabase = createClient()
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/reset-password`,
    })
    setSent(true)
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-dental-950 via-dental-900 to-teal-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 text-white">
            <div className="w-10 h-10 bg-dental-500 rounded-xl flex items-center justify-center font-bold text-xl">D</div>
            <span className="text-2xl font-bold">DentAccept</span>
          </div>
        </div>
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <Link href="/auth/login" className="flex items-center gap-1 text-sm text-dental-600 mb-6 hover:text-dental-700">
            <ArrowLeft className="w-4 h-4" /> {t('Back to login', 'Volver al inicio de sesión')}
          </Link>
          {sent ? (
            <div className="text-center">
              <div className="text-4xl mb-3">📧</div>
              <h2 className="font-bold text-lg text-slate-900 mb-2">{t('Email sent!', '¡Correo enviado!')}</h2>
              <p className="text-slate-600 text-sm">{t('Check your inbox for a reset link.', 'Revisa tu bandeja de entrada para el enlace de restablecimiento.')}</p>
            </div>
          ) : (
            <>
              <h1 className="text-xl font-bold text-slate-900 mb-2">{t('Reset Password', 'Restablecer Contraseña')}</h1>
              <p className="text-slate-500 text-sm mb-6">{t("Enter your email and we'll send a reset link.", 'Ingresa tu correo y te enviaremos un enlace.')}</p>
              <form onSubmit={handleSubmit} className="space-y-4">
                <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                  placeholder={t('Your email', 'Tu correo')} className="input-field" />
                <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
                  {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                  {t('Send Reset Link', 'Enviar Enlace')}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
