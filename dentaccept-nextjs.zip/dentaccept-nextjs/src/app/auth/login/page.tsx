'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/browser'
import LanguageToggle from '@/components/LanguageToggle'
import { useLanguage } from '@/context/LanguageContext'
import { Loader2 } from 'lucide-react'

export default function LoginPage() {
  const { t } = useLanguage()
  const router = useRouter()
  const supabase = createClient()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) { setError(error.message); setLoading(false) }
    else router.push('/dashboard')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-dental-950 via-dental-900 to-teal-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 text-white">
            <div className="w-10 h-10 bg-dental-500 rounded-xl flex items-center justify-center font-bold text-xl">D</div>
            <span className="text-2xl font-bold">DentAccept</span>
          </div>
          <p className="text-dental-300 mt-2 text-sm">{t('Sign in to your practice dashboard', 'Inicia sesión en el panel de tu consultorio')}</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-xl font-bold text-slate-900">{t('Welcome back', 'Bienvenido de vuelta')}</h1>
            <LanguageToggle />
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm">{error}</div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">{t('Email', 'Correo electrónico')}</label>
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                className="input-field" placeholder="dr.smith@example.com" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">{t('Password', 'Contraseña')}</label>
              <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
                className="input-field" placeholder="••••••••" />
            </div>
            <div className="flex justify-end">
              <Link href="/auth/forgot-password" className="text-sm text-dental-600 hover:text-dental-700">
                {t('Forgot password?', '¿Olvidaste tu contraseña?')}
              </Link>
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              {t('Sign In', 'Iniciar Sesión')}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-slate-500">
            {t("Don't have an account?", '¿No tienes una cuenta?')}{' '}
            <Link href="/auth/signup" className="text-dental-600 font-medium hover:text-dental-700">
              {t('Sign up free', 'Regístrate gratis')}
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
