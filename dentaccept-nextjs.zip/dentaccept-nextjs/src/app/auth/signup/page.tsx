'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/browser'
import LanguageToggle from '@/components/LanguageToggle'
import { useLanguage } from '@/context/LanguageContext'
import { Loader2 } from 'lucide-react'

export default function SignupPage() {
  const { t } = useLanguage()
  const router = useRouter()
  const supabase = createClient()
  const [form, setForm] = useState({ name: '', email: '', password: '', officeName: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  function set(field: string) {
    return (e: React.ChangeEvent<HTMLInputElement>) => setForm((prev) => ({ ...prev, [field]: e.target.value }))
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')
    const { error } = await supabase.auth.signUp({
      email: form.email,
      password: form.password,
      options: { data: { full_name: form.name, office_name: form.officeName } },
    })
    if (error) { setError(error.message); setLoading(false) }
    else setSuccess(true)
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-dental-950 via-dental-900 to-teal-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="text-5xl mb-4">🦷</div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">{t('Check your email!', '¡Revisa tu correo!')}</h2>
          <p className="text-slate-600 text-sm">{t('We sent a confirmation link to', 'Enviamos un enlace de confirmación a')} <strong>{form.email}</strong></p>
          <Link href="/auth/login" className="btn-primary inline-block mt-6">{t('Back to Login', 'Volver al inicio de sesión')}</Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-dental-950 via-dental-900 to-teal-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 text-white">
            <div className="w-10 h-10 bg-dental-500 rounded-xl flex items-center justify-center font-bold text-xl">D</div>
            <span className="text-2xl font-bold">DentAccept</span>
          </div>
        </div>
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-xl font-bold text-slate-900">{t('Create account', 'Crear cuenta')}</h1>
            <LanguageToggle />
          </div>
          {error && <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm">{error}</div>}
          <form onSubmit={handleSubmit} className="space-y-4">
            <input type="text" required placeholder={t('Your name', 'Tu nombre')} value={form.name} onChange={set('name')} className="input-field" />
            <input type="text" required placeholder={t('Practice name', 'Nombre del consultorio')} value={form.officeName} onChange={set('officeName')} className="input-field" />
            <input type="email" required placeholder={t('Email', 'Correo electrónico')} value={form.email} onChange={set('email')} className="input-field" />
            <input type="password" required minLength={8} placeholder={t('Password (8+ chars)', 'Contraseña (8+ caracteres)')} value={form.password} onChange={set('password')} className="input-field" />
            <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              {t('Start Free Trial', 'Comenzar Prueba Gratuita')}
            </button>
          </form>
          <p className="mt-6 text-center text-sm text-slate-500">
            {t('Already have an account?', '¿Ya tienes cuenta?')}{' '}
            <Link href="/auth/login" className="text-dental-600 font-medium">{t('Sign in', 'Iniciar sesión')}</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
