import Link from 'next/link'
import { CheckCircle2, MonitorPlay, Globe, BarChart2, ArrowRight } from 'lucide-react'

const FEATURES = [
  { icon: MonitorPlay, title: 'Chairside Presentations', desc: 'Full-screen, step-by-step procedure presentations designed for iPad landscape.' },
  { icon: Globe, title: 'Bilingual EN/ES', desc: 'One tap switches the entire presentation to Spanish. No separate content needed.' },
  { icon: BarChart2, title: 'Acceptance Analytics', desc: 'Track acceptance rates, preferred language, and case outcomes across your practice.' },
  { icon: CheckCircle2, title: 'Evidence-Based', desc: 'Videos and slides built around what actually moves patients to say yes.' },
]

const PROCEDURES = ['Dental Crown', 'Root Canal', 'Dental Implant', 'Tooth Extraction', 'Teeth Whitening', 'Deep Cleaning (SRP)']

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="flex items-center justify-between px-6 py-4 max-w-6xl mx-auto">
        <div className="flex items-center gap-2 font-bold text-xl text-dental-700">
          <div className="w-8 h-8 bg-dental-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">D</div>
          DentAccept
        </div>
        <div className="flex items-center gap-4">
          <Link href="/auth/login" className="text-slate-600 hover:text-dental-700 text-sm font-medium">Sign In</Link>
          <Link href="/auth/signup" className="btn-primary text-sm py-2 px-4">Start Free Trial</Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="bg-gradient-to-br from-dental-950 via-dental-900 to-teal-900 text-white py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-dental-800/60 text-dental-300 text-sm px-4 py-2 rounded-full mb-6 border border-dental-700">
            🦷 Designed for chairside presentation
          </div>
          <h1 className="text-4xl lg:text-6xl font-extrabold mb-6 leading-tight">
            Help patients say{' '}
            <span className="text-dental-400">yes</span>{' '}
            to their treatment
          </h1>
          <p className="text-dental-200 text-xl mb-10 max-w-2xl mx-auto">
            Bilingual dental procedure videos that build trust, reduce anxiety, and increase case acceptance — right in your chair.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/signup" className="btn-success flex items-center justify-center gap-2">
              Start Free Trial <ArrowRight className="w-5 h-5" />
            </Link>
            <Link href="/chairside?procedure=p1000000-0000-0000-0000-000000000001"
              className="btn-secondary flex items-center justify-center gap-2">
              <MonitorPlay className="w-5 h-5" /> See Demo
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-6 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Everything you need chairside</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {FEATURES.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="card p-6">
              <div className="w-12 h-12 bg-dental-100 rounded-xl flex items-center justify-center mb-4">
                <Icon className="w-6 h-6 text-dental-600" />
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">{title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Procedures */}
      <section className="py-16 px-6 bg-slate-50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-slate-900 mb-2">6 procedures included. More coming.</h2>
          <p className="text-slate-500 mb-8">All in English and Spanish, with video, What to Expect, and Consequences slides.</p>
          <div className="flex flex-wrap justify-center gap-3">
            {PROCEDURES.map((p) => (
              <span key={p} className="bg-white border border-dental-200 text-dental-700 px-4 py-2 rounded-full text-sm font-medium shadow-sm">{p}</span>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 bg-dental-950 text-white text-center">
        <h2 className="text-3xl font-bold mb-4">Ready to increase case acceptance?</h2>
        <p className="text-dental-300 mb-8">Free 14-day trial. No credit card required.</p>
        <Link href="/auth/signup" className="btn-success inline-flex items-center gap-2">
          Get Started Free <ArrowRight className="w-5 h-5" />
        </Link>
      </section>

      {/* Footer */}
      <footer className="text-center py-8 text-slate-400 text-sm">
        © {new Date().getFullYear()} DentAccept. Built for dental practices.
      </footer>
    </div>
  )
}
