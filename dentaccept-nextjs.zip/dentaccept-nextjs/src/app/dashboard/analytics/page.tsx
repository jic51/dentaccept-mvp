'use client'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/browser'
import { useLanguage } from '@/context/LanguageContext'
import type { Presentation } from '@/types'
import { TrendingUp, CheckCircle2, XCircle, Clock, PhoneCall, BarChart2 } from 'lucide-react'

type OutcomeKey = 'accepted' | 'declined' | 'pending' | 'callback'

const OUTCOME_CONFIG: Record<OutcomeKey, { label: [string, string]; icon: React.ElementType; color: string; bg: string }> = {
  accepted: { label: ['Accepted', 'Aceptados'], icon: CheckCircle2, color: 'text-success-600', bg: 'bg-success-50' },
  declined: { label: ['Declined', 'Rechazados'], icon: XCircle, color: 'text-red-600', bg: 'bg-red-50' },
  pending:  { label: ['Pending', 'Pendientes'], icon: Clock, color: 'text-yellow-600', bg: 'bg-yellow-50' },
  callback: { label: ['Callback', 'Seguimiento'], icon: PhoneCall, color: 'text-blue-600', bg: 'bg-blue-50' },
}

export default function AnalyticsPage() {
  const { t } = useLanguage()
  const supabase = createClient()
  const [presentations, setPresentations] = useState<Presentation[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  async function loadData() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const { data: member } = await supabase.from('office_members').select('office_id').eq('user_id', user.id).single()
    if (!member) { setLoading(false); return }
    const { data } = await supabase.from('presentations')
      .select('*').eq('office_id', member.office_id)
      .order('started_at', { ascending: false }).limit(200)
    setPresentations(data ?? [])
    setLoading(false)
  }

  const total = presentations.length
  const outcomeCount = presentations.reduce((acc, p) => {
    if (p.outcome) acc[p.outcome as OutcomeKey] = (acc[p.outcome as OutcomeKey] ?? 0) + 1
    return acc
  }, {} as Record<OutcomeKey, number>)

  const acceptRate = total > 0 ? Math.round(((outcomeCount.accepted ?? 0) / total) * 100) : 0
  const enCount = presentations.filter((p) => p.language === 'en').length
  const esCount = presentations.filter((p) => p.language === 'es').length

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-2xl font-bold text-slate-900 mb-6">{t('Analytics', 'Analíticas')}</h1>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-dental-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <>
          {/* Summary cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="card p-5">
              <BarChart2 className="w-6 h-6 text-dental-600 mb-2" />
              <div className="text-3xl font-bold text-slate-900">{total}</div>
              <div className="text-sm text-slate-500">{t('Total Presentations', 'Presentaciones Totales')}</div>
            </div>
            <div className="card p-5">
              <TrendingUp className="w-6 h-6 text-success-600 mb-2" />
              <div className="text-3xl font-bold text-success-700">{acceptRate}%</div>
              <div className="text-sm text-slate-500">{t('Acceptance Rate', 'Tasa de Aceptación')}</div>
            </div>
            <div className="card p-5">
              <div className="text-2xl mb-2">🇺🇸</div>
              <div className="text-3xl font-bold text-slate-900">{enCount}</div>
              <div className="text-sm text-slate-500">{t('English Sessions', 'Sesiones en Inglés')}</div>
            </div>
            <div className="card p-5">
              <div className="text-2xl mb-2">🇲🇽</div>
              <div className="text-3xl font-bold text-slate-900">{esCount}</div>
              <div className="text-sm text-slate-500">{t('Spanish Sessions', 'Sesiones en Español')}</div>
            </div>
          </div>

          {/* Outcomes breakdown */}
          <div className="card p-6 mb-8">
            <h2 className="font-semibold text-slate-900 mb-4">{t('Outcomes Breakdown', 'Desglose de Resultados')}</h2>
            <div className="grid grid-cols-2 gap-4">
              {(Object.keys(OUTCOME_CONFIG) as OutcomeKey[]).map((key) => {
                const { label, icon: Icon, color, bg } = OUTCOME_CONFIG[key]
                const count = outcomeCount[key] ?? 0
                const pct = total > 0 ? Math.round((count / total) * 100) : 0
                return (
                  <div key={key} className={`flex items-center gap-4 p-4 rounded-xl ${bg}`}>
                    <Icon className={`w-8 h-8 ${color}`} />
                    <div>
                      <div className="font-bold text-xl text-slate-900">{count}</div>
                      <div className="text-sm text-slate-600">{t(label[0], label[1])} ({pct}%)</div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Recent presentations */}
          <div className="card">
            <div className="p-4 border-b border-slate-100 font-semibold text-slate-900">{t('Recent Presentations', 'Presentaciones Recientes')}</div>
            {presentations.length === 0 ? (
              <p className="text-slate-500 text-sm p-6 text-center">{t('No presentations yet. Start a chairside session!', '¡Aún no hay presentaciones. ¡Inicia una sesión chairside!')}</p>
            ) : (
              <div className="divide-y divide-slate-50">
                {presentations.slice(0, 20).map((p) => {
                  const outConfig = p.outcome ? OUTCOME_CONFIG[p.outcome as OutcomeKey] : null
                  return (
                    <div key={p.id} className="flex items-center justify-between px-4 py-3">
                      <div>
                        <span className="text-xs text-slate-400">{new Date(p.started_at).toLocaleDateString()}</span>
                        <span className="ml-3 text-xs bg-dental-50 text-dental-700 px-2 py-0.5 rounded-full uppercase">{p.language}</span>
                      </div>
                      {outConfig ? (
                        <span className={`text-xs font-medium px-2 py-1 rounded-full ${outConfig.bg} ${outConfig.color}`}>
                          {t(outConfig.label[0], outConfig.label[1])}
                        </span>
                      ) : (
                        <span className="text-xs text-slate-400">{t('No outcome', 'Sin resultado')}</span>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  )
}
