'use client'
import { useState, useEffect, useMemo } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/browser'
import SearchBar from '@/components/SearchBar'
import CategoryFilter from '@/components/CategoryFilter'
import ProcedureCard from '@/components/ProcedureCard'
import LanguageToggle from '@/components/LanguageToggle'
import { useLanguage } from '@/context/LanguageContext'
import type { Category, ProcedureWithCategory } from '@/types'
import { Loader2 } from 'lucide-react'

export default function LibraryPage() {
  const { t } = useLanguage()
  const router = useRouter()
  const supabase = createClient()

  const [procedures, setProcedures] = useState<ProcedureWithCategory[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set())
  const [search, setSearch] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false)
  const [loading, setLoading] = useState(true)
  const [officeId, setOfficeId] = useState<string | null>(null)

  useEffect(() => {
    loadData()
  }, [])

  async function loadData() {
    setLoading(true)
    const [{ data: procs }, { data: cats }, { data: { user } }] = await Promise.all([
      supabase.from('procedures').select('*, categories(*)').eq('is_active', true).order('name_en'),
      supabase.from('categories').select('*').order('sort_order'),
      supabase.auth.getUser(),
    ])
    setProcedures((procs as ProcedureWithCategory[]) ?? [])
    setCategories(cats ?? [])

    if (user) {
      const { data: member } = await supabase.from('office_members').select('office_id').eq('user_id', user.id).single()
      if (member) {
        setOfficeId(member.office_id)
        const { data: favs } = await supabase.from('favorites').select('procedure_id').eq('office_id', member.office_id)
        setFavoriteIds(new Set((favs ?? []).map((f) => f.procedure_id)))
      }
    }
    setLoading(false)
  }

  async function toggleFavorite(procedureId: string) {
    if (!officeId) return
    if (favoriteIds.has(procedureId)) {
      await supabase.from('favorites').delete().eq('office_id', officeId).eq('procedure_id', procedureId)
      setFavoriteIds((prev) => { const s = new Set(prev); s.delete(procedureId); return s })
    } else {
      await supabase.from('favorites').insert({ office_id: officeId, procedure_id: procedureId })
      setFavoriteIds((prev) => new Set(prev).add(procedureId))
    }
  }

  const filtered = useMemo(() => {
    return procedures.filter((p) => {
      const name = p.name_en.toLowerCase() + ' ' + p.name_es.toLowerCase()
      const matchSearch = !search || name.includes(search.toLowerCase())
      const matchCat = !selectedCategory || p.category_id === selectedCategory
      const matchFav = !showFavoritesOnly || favoriteIds.has(p.id)
      return matchSearch && matchCat && matchFav
    })
  }, [procedures, search, selectedCategory, showFavoritesOnly, favoriteIds])

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">{t('Procedure Library', 'Biblioteca de Procedimientos')}</h1>
          <p className="text-slate-500 text-sm mt-1">{procedures.length} {t('procedures available', 'procedimientos disponibles')}</p>
        </div>
        <LanguageToggle />
      </div>

      {/* Controls */}
      <div className="space-y-4 mb-6">
        <SearchBar value={search} onChange={setSearch} />
        <div className="flex items-center gap-4 flex-wrap">
          <CategoryFilter categories={categories} selected={selectedCategory} onChange={setSelectedCategory} />
          <button
            onClick={() => setShowFavoritesOnly((v) => !v)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
              showFavoritesOnly ? 'bg-red-500 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:border-red-300'
            }`}
          >
            ♥ {t('Favorites', 'Favoritos')} {favoriteIds.size > 0 && `(${favoriteIds.size})`}
          </button>
        </div>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 text-dental-500 animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20 text-slate-500">
          <p className="text-lg font-medium">{t('No procedures found', 'No se encontraron procedimientos')}</p>
          <p className="text-sm mt-1">{t('Try a different search', 'Intenta con otra búsqueda')}</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((p) => (
            <ProcedureCard
              key={p.id}
              procedure={p}
              isFavorite={favoriteIds.has(p.id)}
              onToggleFavorite={toggleFavorite}
              onPresent={(id) => router.push(`/chairside?procedure=${id}`)}
            />
          ))}
        </div>
      )}
    </div>
  )
}
