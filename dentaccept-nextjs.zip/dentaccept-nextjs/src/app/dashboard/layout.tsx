'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/browser'
import { useLanguage } from '@/context/LanguageContext'
import LanguageToggle from '@/components/LanguageToggle'
import {
  LayoutDashboard, BookOpen, MonitorPlay, BarChart2,
  Settings, LogOut, Menu, X, ChevronRight
} from 'lucide-react'

const NAV_ITEMS = [
  { href: '/dashboard', icon: LayoutDashboard, labelEn: 'Dashboard', labelEs: 'Panel' },
  { href: '/dashboard/library', icon: BookOpen, labelEn: 'Library', labelEs: 'Biblioteca' },
  { href: '/dashboard/analytics', icon: BarChart2, labelEn: 'Analytics', labelEs: 'Analíticas' },
  { href: '/dashboard/settings', icon: Settings, labelEn: 'Settings', labelEs: 'Configuración' },
]

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { t } = useLanguage()
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClient()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [user, setUser] = useState<{ email?: string } | null>(null)

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user))
  }, [])

  async function signOut() {
    await supabase.auth.signOut()
    router.push('/auth/login')
  }

  const NavLink = ({ href, icon: Icon, labelEn, labelEs }: typeof NAV_ITEMS[0]) => {
    const active = pathname === href || (href !== '/dashboard' && pathname.startsWith(href))
    return (
      <Link href={href} onClick={() => setSidebarOpen(false)}
        className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
          active ? 'bg-dental-600 text-white shadow-sm' : 'text-slate-600 hover:bg-dental-50 hover:text-dental-700'
        }`}>
        <Icon className="w-5 h-5 flex-shrink-0" />
        <span className="font-medium">{t(labelEn, labelEs)}</span>
        {active && <ChevronRight className="w-4 h-4 ml-auto" />}
      </Link>
    )
  }

  const Sidebar = () => (
    <aside className="flex flex-col h-full bg-white border-r border-slate-100">
      {/* Logo */}
      <div className="p-6 border-b border-slate-100">
        <Link href="/dashboard" className="flex items-center gap-2">
          <div className="w-9 h-9 bg-dental-600 rounded-xl flex items-center justify-center text-white font-bold">D</div>
          <span className="text-xl font-bold text-slate-900">DentAccept</span>
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-4 space-y-1">
        {NAV_ITEMS.map((item) => <NavLink key={item.href} {...item} />)}
      </nav>

      {/* Chairside CTA */}
      <div className="p-4">
        <Link href="/chairside" className="flex items-center gap-2 bg-dental-600 hover:bg-dental-700 text-white px-4 py-3 rounded-xl transition-colors font-medium text-sm">
          <MonitorPlay className="w-4 h-4" />
          {t('Chairside Mode', 'Modo Chairside')}
        </Link>
      </div>

      {/* User */}
      <div className="p-4 border-t border-slate-100">
        <div className="flex items-center justify-between">
          <div className="min-w-0">
            <p className="text-xs text-slate-500 truncate">{user?.email}</p>
          </div>
          <button onClick={signOut} className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  )

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Desktop sidebar */}
      <div className="hidden lg:block w-64 flex-shrink-0">
        <Sidebar />
      </div>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setSidebarOpen(false)} />
          <div className="absolute left-0 top-0 h-full w-64">
            <Sidebar />
          </div>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile header */}
        <header className="lg:hidden flex items-center justify-between px-4 py-3 bg-white border-b border-slate-100">
          <button onClick={() => setSidebarOpen(true)} className="p-2 rounded-lg hover:bg-slate-100">
            <Menu className="w-5 h-5 text-slate-600" />
          </button>
          <span className="font-bold text-dental-700">DentAccept</span>
          <LanguageToggle size="sm" />
        </header>

        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  )
}
