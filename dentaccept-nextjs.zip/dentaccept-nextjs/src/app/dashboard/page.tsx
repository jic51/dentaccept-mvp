import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { BookOpen, MonitorPlay, TrendingUp, Users } from 'lucide-react'

export default async function DashboardPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  // Quick stats (mock for demo — real stats come from analytics page)
  const stats = [
    { label: 'Presentations Today', value: '—', icon: MonitorPlay, color: 'text-dental-600', bg: 'bg-dental-50' },
    { label: 'Acceptance Rate', value: '—', icon: TrendingUp, color: 'text-success-600', bg: 'bg-success-50' },
    { label: 'Total Procedures', value: '6', icon: BookOpen, color: 'text-teal-600', bg: 'bg-teal-50' },
    { label: 'Active Staff', value: '1', icon: Users, color: 'text-purple-600', bg: 'bg-purple-50' },
  ]

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-900">Good morning 👋</h1>
        <p className="text-slate-500 mt-1">Ready to present today?</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map(({ label, value, icon: Icon, color, bg }) => (
          <div key={label} className="card p-5">
            <div className={`inline-flex p-2.5 rounded-xl ${bg} mb-3`}>
              <Icon className={`w-5 h-5 ${color}`} />
            </div>
            <div className="text-2xl font-bold text-slate-900">{value}</div>
            <div className="text-sm text-slate-500 mt-0.5">{label}</div>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div className="grid md:grid-cols-2 gap-4">
        <Link href="/chairside" className="card p-6 flex items-center gap-4 hover:border-dental-300 group">
          <div className="w-12 h-12 bg-dental-100 rounded-xl flex items-center justify-center group-hover:bg-dental-200 transition-colors">
            <MonitorPlay className="w-6 h-6 text-dental-600" />
          </div>
          <div>
            <div className="font-semibold text-slate-900">Start Chairside Session</div>
            <div className="text-sm text-slate-500">Present a procedure to a patient</div>
          </div>
        </Link>
        <Link href="/dashboard/library" className="card p-6 flex items-center gap-4 hover:border-dental-300 group">
          <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center group-hover:bg-teal-200 transition-colors">
            <BookOpen className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="font-semibold text-slate-900">Browse Library</div>
            <div className="text-sm text-slate-500">View and manage procedure videos</div>
          </div>
        </Link>
      </div>
    </div>
  )
}
