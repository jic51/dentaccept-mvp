'use client'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/browser'
import { useLanguage } from '@/context/LanguageContext'
import LanguageToggle from '@/components/LanguageToggle'
import { Save, Loader2, CheckCircle2 } from 'lucide-react'

export default function SettingsPage() {
  const { t } = useLanguage()
  const supabase = createClient()
  const [email, setEmail] = useState('')
  const [officeName, setOfficeName] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    loadProfile()
  }, [])

  async function loadProfile() {
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      setEmail(user.email ?? '')
      setOfficeName(user.user_metadata?.office_name ?? '')
    }
    setLoading(false)
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    await supabase.auth.updateUser({ data: { office_name: officeName } })
    setSaving(false)
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold text-slate-900 mb-6">{t('Settings', 'Configuración')}</h1>

      <div className="card p-6 mb-6">
        <h2 className="font-semibold text-slate-900 mb-4">{t('Language Preference', 'Preferencia de Idioma')}</h2>
        <div className="flex items-center gap-3">
          <span className="text-sm text-slate-600">{t('Default presentation language:', 'Idioma de presentación predeterminado:')}</span>
          <LanguageToggle />
        </div>
      </div>

      <div className="card p-6 mb-6">
        <h2 className="font-semibold text-slate-900 mb-4">{t('Practice Information', 'Información del Consultorio')}</h2>
        {loading ? (
          <div className="flex items-center gap-2 text-slate-500"><Loader2 className="w-4 h-4 animate-spin" /> Loading…</div>
        ) : (
          <form onSubmit={handleSave} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">{t('Email', 'Correo electrónico')}</label>
              <input type="email" value={email} disabled className="input-field opacity-50 cursor-not-allowed" />
              <p className="text-xs text-slate-400 mt-1">{t('Contact support to change your email.', 'Contacta soporte para cambiar tu correo.')}</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">{t('Practice Name', 'Nombre del Consultorio')}</label>
              <input type="text" value={officeName} onChange={(e) => setOfficeName(e.target.value)} className="input-field" />
            </div>
            <button type="submit" disabled={saving} className="btn-primary flex items-center gap-2">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : saved ? <CheckCircle2 className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              {saved ? t('Saved!', '¡Guardado!') : t('Save Changes', 'Guardar Cambios')}
            </button>
          </form>
        )}
      </div>

      <div className="card p-6">
        <h2 className="font-semibold text-slate-900 mb-2">{t('Danger Zone', 'Zona de Peligro')}</h2>
        <p className="text-sm text-slate-500 mb-4">{t('These actions cannot be undone.', 'Estas acciones no se pueden deshacer.')}</p>
        <button className="btn-danger text-sm">{t('Delete Account', 'Eliminar Cuenta')}</button>
      </div>
    </div>
  )
}
