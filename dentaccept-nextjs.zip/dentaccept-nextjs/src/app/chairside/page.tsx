'use client'
import { useState, useEffect, Suspense } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/browser'
import { useLanguage } from '@/context/LanguageContext'
import LanguageToggle from '@/components/LanguageToggle'
import VideoPlayer from '@/components/VideoPlayer'
import OutcomeSelector from '@/components/OutcomeSelector'
import type { Procedure, PresentationOutcome, ChairsideStep } from '@/types'
import { ArrowLeft, ArrowRight, X, CheckCircle2, AlertCircle } from 'lucide-react'

function ChairsideContent() {
  const { t, language } = useLanguage()
  const searchParams = useSearchParams()
  const router = useRouter()
  const supabase = createClient()

  const procedureId = searchParams.get('procedure')
  const [procedure, setProcedure] = useState<Procedure | null>(null)
  const [step, setStep] = useState<ChairsideStep>('video')
  const [presentationId, setPresentationId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [done, setDone] = useState(false)
  const [loading, setLoading] = useState(true)

  const STEPS: ChairsideStep[] = ['video', 'expect', 'consequences', 'decision']

  useEffect(() => {
    if (!procedureId) { router.push('/dashboard/library'); return }
    supabase.from('procedures').select('*').eq('id', procedureId).single()
      .then(({ data }) => { setProcedure(data); setLoading(false) })
    // Start presentation session
    supabase.auth.getUser().then(async ({ data: { user } }) => {
      let officeId: string | null = null
      if (user) {
        const { data: m } = await supabase.from('office_members').select('office_id').eq('user_id', user.id).single()
        officeId = m?.office_id ?? null
      }
      if (officeId) {
        const { data: pres } = await supabase.from('presentations')
          .insert({ office_id: officeId, procedure_id: procedureId!, language, presented_by: user?.id })
          .select('id').single()
        if (pres) setPresentationId(pres.id)
      }
    })
  }, [procedureId])

  async function recordOutcome(outcome: PresentationOutcome) {
    setSaving(true)
    if (presentationId) {
      await supabase.from('presentations').update({ outcome, completed_at: new Date().toISOString() }).eq('id', presentationId)
    }
    setSaving(false)
    setDone(true)
  }

  const stepIndex = STEPS.indexOf(step)

  function next() { if (stepIndex < STEPS.length - 1) setStep(STEPS[stepIndex + 1]) }
  function prev() { if (stepIndex > 0) setStep(STEPS[stepIndex - 1]) }

  const stepLabels: Record<ChairsideStep, [string, string]> = {
    video: ['Watch Video', 'Ver Video'],
    expect: ['What to Expect', 'Qué Esperar'],
    consequences: ['If Left Untreated', 'Sin Tratamiento'],
    decision: ['Your Decision', 'Tu Decisión'],
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-dental-950 flex items-center justify-center">
        <div className="text-dental-400 text-lg">Loading…</div>
      </div>
    )
  }

  if (!procedure) return null

  if (done) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-dental-950 to-teal-900 flex items-center justify-center">
        <div className="text-center text-white animate-fade-in">
          <CheckCircle2 className="w-20 h-20 text-success-400 mx-auto mb-6" />
          <h2 className="text-3xl font-bold mb-2">{t('Thank you!', '¡Gracias!')}</h2>
          <p className="text-dental-300 text-lg mb-8">{t('Your response has been recorded.', 'Tu respuesta ha sido registrada.')}</p>
          <button onClick={() => router.push('/dashboard')} className="btn-secondary">
            {t('Return to Dashboard', 'Volver al Panel')}
          </button>
        </div>
      </div>
    )
  }

  const expectSlides = (language === 'es' ? procedure.expect_es : procedure.expect_en) as string[]
  const consequenceSlides = (language === 'es' ? procedure.consequences_es : procedure.consequences_en) as string[]

  return (
    <div className="min-h-screen bg-dental-950 flex flex-col chairside-mode">
      {/* Top bar */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-dental-800">
        <button onClick={() => router.back()} className="text-dental-400 hover:text-white transition-colors flex items-center gap-2">
          <X className="w-5 h-5" />
          <span className="text-sm">{t('Exit', 'Salir')}</span>
        </button>

        {/* Step indicator */}
        <div className="flex items-center gap-2">
          {STEPS.map((s, i) => (
            <button key={s} onClick={() => i <= stepIndex && setStep(s)} className="flex items-center gap-2">
              <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-200 ${
                i === stepIndex ? 'bg-dental-500 text-white scale-110'
                : i < stepIndex ? 'bg-dental-700 text-dental-300'
                : 'bg-dental-900 text-dental-600'
              }`}>
                {i + 1}
              </div>
              {i < STEPS.length - 1 && <div className={`w-8 h-0.5 ${i < stepIndex ? 'bg-dental-500' : 'bg-dental-800'}`} />}
            </button>
          ))}
        </div>

        <LanguageToggle size="sm" className="border-dental-700" />
      </header>

      {/* Step title */}
      <div className="text-center pt-6 pb-2">
        <p className="text-dental-400 text-sm uppercase tracking-widest font-medium">
          {t(stepLabels[step][0], stepLabels[step][1])}
        </p>
        <h1 className="text-white text-2xl lg:text-3xl font-bold mt-1">
          {t(procedure.name_en, procedure.name_es)}
        </h1>
      </div>

      {/* Content */}
      <main className="flex-1 px-6 py-6 flex flex-col items-center justify-center max-w-4xl mx-auto w-full animate-fade-in">
        {step === 'video' && (
          <div className="w-full">
            <VideoPlayer url={procedure.video_url ?? 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'} autoPlay={false} />
            <p className="text-dental-300 text-center mt-4 text-sm">
              {t(procedure.description_en ?? '', procedure.description_es ?? '')}
            </p>
          </div>
        )}

        {step === 'expect' && (
          <div className="w-full max-w-2xl">
            <ul className="space-y-3">
              {expectSlides.map((item, i) => (
                <li key={i} className="flex items-start gap-4 bg-dental-900/60 rounded-2xl p-5 animate-slide-up"
                    style={{ animationDelay: `${i * 0.1}s` }}>
                  <div className="w-8 h-8 bg-dental-600 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0">
                    {i + 1}
                  </div>
                  <p className="text-white text-lg leading-relaxed">{item}</p>
                </li>
              ))}
            </ul>
          </div>
        )}

        {step === 'consequences' && (
          <div className="w-full max-w-2xl">
            <div className="flex items-center gap-3 mb-4 text-red-400">
              <AlertCircle className="w-6 h-6" />
              <p className="font-semibold">{t('Without treatment, you risk:', 'Sin tratamiento, usted se arriesga a:')}</p>
            </div>
            <ul className="space-y-3">
              {consequenceSlides.map((item, i) => (
                <li key={i} className="flex items-start gap-4 bg-red-950/40 border border-red-900/50 rounded-2xl p-5 animate-slide-up"
                    style={{ animationDelay: `${i * 0.1}s` }}>
                  <div className="w-3 h-3 bg-red-500 rounded-full flex-shrink-0 mt-2" />
                  <p className="text-red-100 text-lg leading-relaxed">{item}</p>
                </li>
              ))}
            </ul>
          </div>
        )}

        {step === 'decision' && (
          <div className="w-full flex flex-col items-center gap-8">
            <p className="text-dental-200 text-xl text-center">
              {t('How would you like to proceed?', '¿Cómo deseas proceder?')}
            </p>
            <OutcomeSelector onSelect={recordOutcome} loading={saving} />
          </div>
        )}
      </main>

      {/* Navigation */}
      {step !== 'decision' && (
        <footer className="flex items-center justify-between px-6 py-5 border-t border-dental-800">
          <button onClick={prev} disabled={stepIndex === 0}
            className="flex items-center gap-2 text-dental-400 hover:text-white disabled:opacity-30 transition-colors px-4 py-2">
            <ArrowLeft className="w-5 h-5" />
            {t('Back', 'Atrás')}
          </button>
          <button onClick={next}
            className="flex items-center gap-2 bg-dental-600 hover:bg-dental-500 text-white px-8 py-3 rounded-xl font-semibold transition-colors">
            {t('Next', 'Siguiente')}
            <ArrowRight className="w-5 h-5" />
          </button>
        </footer>
      )}
    </div>
  )
}

export default function ChairsidePage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-dental-950 flex items-center justify-center text-dental-400">Loading…</div>}>
      <ChairsideContent />
    </Suspense>
  )
}
