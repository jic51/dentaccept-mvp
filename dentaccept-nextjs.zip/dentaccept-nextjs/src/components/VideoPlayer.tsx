'use client'
import { useState, useRef } from 'react'
import dynamic from 'next/dynamic'
import { Loader2 } from 'lucide-react'

const ReactPlayer = dynamic(() => import('react-player/lazy'), { ssr: false })

interface Props {
  url: string
  onEnded?: () => void
  autoPlay?: boolean
}

export default function VideoPlayer({ url, onEnded, autoPlay = false }: Props) {
  const [ready, setReady] = useState(false)
  const [playing, setPlaying] = useState(autoPlay)

  return (
    <div className="relative w-full aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl">
      {!ready && (
        <div className="absolute inset-0 flex items-center justify-center bg-dental-950">
          <Loader2 className="w-10 h-10 text-dental-400 animate-spin" />
        </div>
      )}
      <ReactPlayer
        url={url}
        width="100%"
        height="100%"
        playing={playing}
        controls={true}
        onReady={() => setReady(true)}
        onEnded={onEnded}
        config={{
          youtube: { playerVars: { modestbranding: 1, rel: 0 } },
        }}
      />
    </div>
  )
}
