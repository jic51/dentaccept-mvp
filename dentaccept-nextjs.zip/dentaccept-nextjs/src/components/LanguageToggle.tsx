'use client'
import { useLanguage } from '@/context/LanguageContext'

interface Props { className?: string; size?: 'sm' | 'md' | 'lg' }

export default function LanguageToggle({ className = '', size = 'md' }: Props) {
  const { language, setLanguage } = useLanguage()
  const sizes = { sm: 'text-xs px-2 py-1', md: 'text-sm px-3 py-1.5', lg: 'text-base px-4 py-2' }

  return (
    <div className={`inline-flex rounded-lg border border-dental-200 overflow-hidden ${className}`}>
      {(['en', 'es'] as const).map((lang) => (
        <button
          key={lang}
          onClick={() => setLanguage(lang)}
          className={`${sizes[size]} font-semibold transition-all duration-200 ${
            language === lang
              ? 'bg-dental-600 text-white'
              : 'bg-white text-dental-600 hover:bg-dental-50'
          }`}
        >
          {lang.toUpperCase()}
        </button>
      ))}
    </div>
  )
}
