'use client'
import Image from 'next/image'
import { Play, Heart, Clock } from 'lucide-react'
import { useLanguage } from '@/context/LanguageContext'
import type { ProcedureWithCategory } from '@/types'

interface Props {
  procedure: ProcedureWithCategory
  isFavorite: boolean
  onToggleFavorite: (id: string) => void
  onPresent: (id: string) => void
}

function formatDuration(seconds: number | null): string {
  if (!seconds) return ''
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return m > 0 ? `${m}m ${s > 0 ? s + 's' : ''}` : `${s}s`
}

export default function ProcedureCard({ procedure, isFavorite, onToggleFavorite, onPresent }: Props) {
  const { t } = useLanguage()

  return (
    <div className="card group cursor-pointer overflow-hidden"
         onClick={() => onPresent(procedure.id)}>
      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden bg-dental-100">
        {procedure.thumbnail_url ? (
          <Image
            src={procedure.thumbnail_url}
            alt={t(procedure.name_en, procedure.name_es)}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Play className="w-12 h-12 text-dental-400" />
          </div>
        )}
        {/* Play overlay */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
          <div className="bg-white/90 rounded-full p-4 shadow-lg">
            <Play className="w-8 h-8 text-dental-600 fill-dental-600" />
          </div>
        </div>
        {/* Duration badge */}
        {procedure.duration_seconds && (
          <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded-md flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {formatDuration(procedure.duration_seconds)}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            {procedure.categories && (
              <span className="text-xs font-medium text-dental-600 uppercase tracking-wide">
                {t(procedure.categories.name_en, procedure.categories.name_es)}
              </span>
            )}
            <h3 className="font-semibold text-slate-900 mt-0.5 group-hover:text-dental-700 transition-colors">
              {t(procedure.name_en, procedure.name_es)}
            </h3>
            <p className="text-sm text-slate-500 mt-1 line-clamp-2">
              {t(procedure.description_en ?? '', procedure.description_es ?? '')}
            </p>
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); onToggleFavorite(procedure.id) }}
            className="flex-shrink-0 p-1.5 rounded-lg hover:bg-red-50 transition-colors"
          >
            <Heart className={`w-5 h-5 transition-colors ${isFavorite ? 'fill-red-500 text-red-500' : 'text-slate-300 hover:text-red-400'}`} />
          </button>
        </div>
        {/* Tags */}
        {procedure.tags?.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1">
            {procedure.tags.slice(0, 3).map((tag) => (
              <span key={tag} className="text-xs bg-dental-50 text-dental-700 px-2 py-0.5 rounded-full">
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
