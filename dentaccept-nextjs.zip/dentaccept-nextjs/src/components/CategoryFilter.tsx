'use client'
import { useLanguage } from '@/context/LanguageContext'
import type { Category } from '@/types'

interface Props {
  categories: Category[]
  selected: string | null
  onChange: (id: string | null) => void
}

export default function CategoryFilter({ categories, selected, onChange }: Props) {
  const { t } = useLanguage()
  return (
    <div className="flex flex-wrap gap-2">
      <button
        onClick={() => onChange(null)}
        className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
          selected === null
            ? 'bg-dental-600 text-white shadow-sm'
            : 'bg-white text-slate-600 border border-slate-200 hover:border-dental-300 hover:text-dental-600'
        }`}
      >
        {t('All', 'Todos')}
      </button>
      {categories.map((cat) => (
        <button
          key={cat.id}
          onClick={() => onChange(cat.id)}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
            selected === cat.id
              ? 'bg-dental-600 text-white shadow-sm'
              : 'bg-white text-slate-600 border border-slate-200 hover:border-dental-300 hover:text-dental-600'
          }`}
        >
          {t(cat.name_en, cat.name_es)}
        </button>
      ))}
    </div>
  )
}
