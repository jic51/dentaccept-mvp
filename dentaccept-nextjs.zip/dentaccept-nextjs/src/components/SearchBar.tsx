'use client'
import { useState } from 'react'
import { Search, X } from 'lucide-react'
import { useLanguage } from '@/context/LanguageContext'

interface Props {
  value: string
  onChange: (v: string) => void
  className?: string
}

export default function SearchBar({ value, onChange, className = '' }: Props) {
  const { t } = useLanguage()
  return (
    <div className={`relative ${className}`}>
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={t('Search procedures…', 'Buscar procedimientos…')}
        className="input-field pl-10 pr-10"
      />
      {value && (
        <button
          onClick={() => onChange('')}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  )
}
