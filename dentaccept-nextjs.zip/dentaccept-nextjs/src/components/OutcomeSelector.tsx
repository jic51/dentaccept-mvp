'use client'
import { CheckCircle2, XCircle, Clock, PhoneCall } from 'lucide-react'
import { useLanguage } from '@/context/LanguageContext'
import type { PresentationOutcome } from '@/types'

interface Props {
  onSelect: (outcome: PresentationOutcome) => void
  loading?: boolean
}

const OUTCOMES = [
  {
    value: 'accepted' as PresentationOutcome,
    icon: CheckCircle2,
    labelEn: 'Yes! Schedule Me',
    labelEs: '¡Sí! Agéndame',
    descEn: 'Patient accepted treatment',
    descEs: 'El paciente aceptó el tratamiento',
    className: 'border-success-400 bg-success-50 hover:bg-success-100 text-success-700',
    iconClass: 'text-success-600',
  },
  {
    value: 'declined' as PresentationOutcome,
    icon: XCircle,
    labelEn: 'Not Today',
    labelEs: 'Hoy No',
    descEn: 'Patient declined for now',
    descEs: 'El paciente declinó por ahora',
    className: 'border-red-300 bg-red-50 hover:bg-red-100 text-red-700',
    iconClass: 'text-red-500',
  },
  {
    value: 'pending' as PresentationOutcome,
    icon: Clock,
    labelEn: 'Think About It',
    labelEs: 'Lo Pensaré',
    descEn: 'Patient needs more time',
    descEs: 'El paciente necesita más tiempo',
    className: 'border-yellow-300 bg-yellow-50 hover:bg-yellow-100 text-yellow-700',
    iconClass: 'text-yellow-600',
  },
  {
    value: 'callback' as PresentationOutcome,
    icon: PhoneCall,
    labelEn: 'Call Me Later',
    labelEs: 'Llámame Después',
    descEn: 'Schedule a follow-up call',
    descEs: 'Programar una llamada de seguimiento',
    className: 'border-blue-300 bg-blue-50 hover:bg-blue-100 text-blue-700',
    iconClass: 'text-blue-600',
  },
]

export default function OutcomeSelector({ onSelect, loading = false }: Props) {
  const { t } = useLanguage()

  return (
    <div className="grid grid-cols-2 gap-4 w-full max-w-2xl mx-auto">
      {OUTCOMES.map(({ value, icon: Icon, labelEn, labelEs, descEn, descEs, className, iconClass }) => (
        <button
          key={value}
          onClick={() => onSelect(value)}
          disabled={loading}
          className={`flex flex-col items-center gap-3 p-6 rounded-2xl border-2 transition-all duration-200
            hover:scale-105 active:scale-95 shadow-sm hover:shadow-lg disabled:opacity-50 ${className}`}
        >
          <Icon className={`w-10 h-10 ${iconClass}`} />
          <div className="text-center">
            <div className="font-bold text-lg">{t(labelEn, labelEs)}</div>
            <div className="text-sm opacity-75 mt-0.5">{t(descEn, descEs)}</div>
          </div>
        </button>
      ))}
    </div>
  )
}
