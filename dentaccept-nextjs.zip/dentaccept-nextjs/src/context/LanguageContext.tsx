'use client'
import { createContext, useContext, useState, useCallback, type ReactNode } from 'react'
import type { Language } from '@/types'

interface LanguageContextValue {
  language: Language
  setLanguage: (lang: Language) => void
  t: (en: string, es: string) => string
  isSpanish: boolean
}

const LanguageContext = createContext<LanguageContextValue | null>(null)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en')

  const t = useCallback(
    (en: string, es: string) => (language === 'es' ? es : en),
    [language]
  )

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isSpanish: language === 'es' }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const ctx = useContext(LanguageContext)
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider')
  return ctx
}
