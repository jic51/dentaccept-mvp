import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        dental: {
          50:  '#eff8ff',
          100: '#dbeffe',
          200: '#b9e0fd',
          300: '#7cc9fb',
          400: '#37aff6',
          500: '#0d95e7',
          600: '#0177c5',
          700: '#025f9f',
          800: '#065183',
          900: '#0b446c',
          950: '#072c48',
        },
        teal: {
          50:  '#effefb',
          100: '#c8fff5',
          200: '#91ffeb',
          300: '#53f6dd',
          400: '#21e4cb',
          500: '#05c7b1',
          600: '#01a091',
          700: '#067f75',
          800: '#0a655d',
          900: '#0d534d',
        },
        success: {
          50:  '#f0fdf4',
          100: '#dcfce7',
          400: '#4ade80',
          500: '#22c55e',
          600: '#16a34a',
          700: '#15803d',
        }
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui'],
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease-out',
        'slide-up': 'slideUp 0.4s ease-out',
      },
      keyframes: {
        fadeIn: { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
        slideUp: { '0%': { transform: 'translateY(20px)', opacity: '0' }, '100%': { transform: 'translateY(0)', opacity: '1' } },
      }
    },
  },
  plugins: [],
}
export default config
